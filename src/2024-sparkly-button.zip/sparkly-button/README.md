# Sparkly Button

A Pen created on CodePen.io. Original URL: [https://codepen.io/simeydotme/pen/WNawXQM](https://codepen.io/simeydotme/pen/WNawXQM).

Inspired by @lukyvj many recent buttons and css expirments recently I wanted to do my own one!